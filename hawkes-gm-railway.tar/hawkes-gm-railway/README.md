# Hawkes-GM High-Frequency Binary Engine

Polymarket 5m/15m market trading engine with real-time dashboard.
Cascade detection via Hawkes process + Bayesian posterior via Glosten-Milgrom.

## Architecture

```
┌─────────────────────────────────────┐
│         Railway Container           │
│                                     │
│  Express Server (port 3000)         │
│  ├── GET /           → Dashboard    │
│  ├── GET /health     → Health check │
│  ├── GET /api/state  → Engine state │
│  ├── GET /api/trades → Trade log    │
│  ├── GET /api/export/trades → CSV   │
│  ├── GET /api/export/snapshot → CSV │
│  └── WS  /ws         → Live state  │
│                                     │
│  Engine Loop (1.5s tick)            │
│  ├── Market scanning                │
│  ├── Hawkes intensity tracking      │
│  ├── GM posterior updates           │
│  ├── Signal generation              │
│  └── Position management            │
└─────────────────────────────────────┘
```

## Deploy to Railway

1. Push to GitHub
2. Connect repo in Railway dashboard
3. Railway auto-detects Dockerfile
4. Set environment variables (see .env.example)
5. Deploy

## Local Development

```bash
npm install
npm start
# Open http://localhost:3000
```

## Current Mode

**Simulation** — engine generates synthetic markets and trades for dashboard development.

## Production Mode (Future)

Replace `src/engine.js` data feed with:
- Polymarket CLOB WebSocket for live trade stream
- Real Hawkes parameter calibration from historical data
- Live order execution via Polygon/CLOB API
- 6-wallet architecture integration

## Endpoints

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/` | GET | Dashboard UI |
| `/health` | GET | Health check (Railway) |
| `/api/state` | GET | Current engine state JSON |
| `/api/trades` | GET | All resolved trades JSON |
| `/api/export/trades` | GET | Download trades CSV |
| `/api/export/snapshot` | GET | Download live market snapshot CSV |
| `/ws` | WS | Real-time state push (1.5s) |
