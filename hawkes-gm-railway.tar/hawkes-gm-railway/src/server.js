require("dotenv").config();
const express = require("express");
const path = require("path");
const { WebSocketServer } = require("ws");
const http = require("http");
const { Engine } = require("./engine");

const app = express();
const PORT = process.env.PORT || 3000;

// ── Serve static files ──
app.use(express.static(path.join(__dirname, "..", "public")));

// ── Health check for Railway ──
app.get("/health", (req, res) => {
  res.json({ status: "ok", uptime: process.uptime(), markets: engine.getActiveCount() });
});

// ── API: current engine state ──
app.get("/api/state", (req, res) => {
  res.json(engine.getState());
});

// ── API: resolved trades ──
app.get("/api/trades", (req, res) => {
  res.json(engine.getResolvedTrades());
});

// ── API: export CSV ──
app.get("/api/export/trades", (req, res) => {
  const csv = engine.exportTradesCSV();
  res.setHeader("Content-Type", "text/csv");
  res.setHeader("Content-Disposition", `attachment; filename=hgm-trades-${new Date().toISOString().slice(0, 10)}.csv`);
  res.send(csv);
});

app.get("/api/export/snapshot", (req, res) => {
  const csv = engine.exportSnapshotCSV();
  res.setHeader("Content-Type", "text/csv");
  res.setHeader("Content-Disposition", `attachment; filename=hgm-snapshot-${new Date().toISOString().slice(0, 10)}.csv`);
  res.send(csv);
});

// ── Catch-all: serve dashboard ──
app.get("*", (req, res) => {
  res.sendFile(path.join(__dirname, "..", "public", "index.html"));
});

// ── HTTP + WebSocket server ──
const server = http.createServer(app);
const wss = new WebSocketServer({ server, path: "/ws" });

// ── Engine instance ──
const engine = new Engine();

// ── WebSocket: push state to connected clients ──
wss.on("connection", (ws) => {
  console.log("[WS] Client connected");
  ws.send(JSON.stringify({ type: "state", data: engine.getState() }));

  ws.on("close", () => console.log("[WS] Client disconnected"));
});

function broadcast(data) {
  const msg = JSON.stringify(data);
  wss.clients.forEach((client) => {
    if (client.readyState === 1) client.send(msg);
  });
}

// ── Engine loop ──
setInterval(() => {
  engine.tick();
  broadcast({ type: "state", data: engine.getState() });
}, 1500);

// ── Start ──
server.listen(PORT, () => {
  console.log(`[HGM] Hawkes-GM Engine running on port ${PORT}`);
  console.log(`[HGM] Dashboard: http://localhost:${PORT}`);
  console.log(`[HGM] WebSocket: ws://localhost:${PORT}/ws`);
  console.log(`[HGM] Health: http://localhost:${PORT}/health`);
});
